To install do the following

tar -zxvf libebf_python_x.x.x.tar.gz
cd libebf_python_x.x.x
python setup.py install

See the html guide for usage
or 
>>>import ebf
>>>help(ebf) 

